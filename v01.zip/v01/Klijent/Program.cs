﻿using Servis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Zajednicko;

namespace Klijent
{
    class Program
    {
        static void Main(string[] args)
        {
            ChannelFactory<IKnjige> factory = new ChannelFactory<IKnjige>(new NetTcpBinding(), new EndpointAddress("net.tcp://localhost:4000/ServisKnjiga"));
            IKnjige kanal = factory.CreateChannel();

            kanal.DodajKnjigu(123, "Hamlet", "Marko", "Markovic", Enumeracija.Zanrovi.krimi, DateTime.Now);
            kanal.DodajKnjigu(111, "Peta simfonija", "Petar", "Petrovic", Enumeracija.Zanrovi.scifi, DateTime.Now);
            string spisak = kanal.SpisakSvihKnjiga();

            Console.WriteLine("Spisak lica: {0}", spisak);
            kanal.ObrisiKnjigu(111);

            Console.WriteLine("Pritisnite [Enter] za zaustavljanje klijenta.");
            Console.ReadLine();
        }
    }
}
