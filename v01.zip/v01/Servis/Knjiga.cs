﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Zajednicko;

namespace Servis
{

    [DataContract]
    public class Knjiga
    {
        // Polja
        private int idKnjige;
        private string imeKnjige;
        private string imeAutora;
        private string prezimeAutora;
        private Enumeracija.Zanrovi zanr;
        private DateTime datumIzdavanja;

        // Propertiji
        [DataMember]
        public int IdKnjige { get => idKnjige; set => idKnjige = value; }
        [DataMember]
        public string ImeKnjige { get => imeKnjige; set => imeKnjige = value; }
        [DataMember]
        public string ImeAutora { get => imeAutora; set => imeAutora = value; }
        [DataMember]
        public string PrezimeAutora { get => prezimeAutora; set => prezimeAutora = value; }
        [DataMember]
        public Enumeracija.Zanrovi Zanr { get => zanr; set => zanr = value; }
        [DataMember]
        public DateTime DatumIzdavanja { get => datumIzdavanja; set => datumIzdavanja = value; }

        // Konstruktor
        public Knjiga(int idKnjige, string imeKnjige, string imeAutora, string prezimeAutora, Enumeracija.Zanrovi zanr, DateTime datumIzdavanja)
        {
            this.idKnjige = idKnjige;
            this.imeKnjige = imeKnjige;
            this.imeAutora = imeAutora;
            this.prezimeAutora = prezimeAutora;
            this.zanr = zanr;
            this.datumIzdavanja = datumIzdavanja;
        }
    }
}
