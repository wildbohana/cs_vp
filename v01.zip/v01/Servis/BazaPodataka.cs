﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Servis
{
    public class BazaPodataka
    {
        public static Dictionary<long, Knjiga> Biblioteka = new Dictionary<long, Knjiga>();
    }
}
