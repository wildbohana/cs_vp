﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zajednicko;

namespace Servis
{
    public class KnjigeServis : IKnjige
    {
        public void DodajKnjigu(int idKnjige, string imeKnjige, string imeAutora, string prezimeAutora, Enumeracija.Zanrovi zanr, DateTime datumIzdavanja)
        {
            if (BazaPodataka.Biblioteka.ContainsKey(idKnjige))
                Console.WriteLine("Ta knjiga se već nalazi u biblioteci.");
            else
                BazaPodataka.Biblioteka.Add(idKnjige, new Knjiga(idKnjige, imeKnjige, imeAutora, prezimeAutora, zanr, datumIzdavanja));
        }

        public void ObrisiKnjigu(int idKnjige)
        {
            if (BazaPodataka.Biblioteka.ContainsKey(idKnjige))
                BazaPodataka.Biblioteka.Remove(idKnjige);
            else
                Console.WriteLine("Ta knjiga se ne nalazi u biblioteci.");
        }

        public string SpisakKnjigaAutor(string prz)
        {
            string retval = "Autor: " + prz + "\n";

            foreach (Knjiga k in BazaPodataka.Biblioteka.Values)
            {
                if (prz.Equals(k.PrezimeAutora))
                {
                    retval += k.IdKnjige;
                    retval += "\t" + k.ImeKnjige;
                    retval += " " + k.ImeAutora;
                    retval += " " + k.PrezimeAutora;
                    retval += " " + k.Zanr;
                    retval += " " + k.DatumIzdavanja;
                }                
            }

            return retval;
        }

        public string SpisakKnjigaGodina(int god)
        {
            string retval = "Godina: " + god + "\n";

            foreach (Knjiga k in BazaPodataka.Biblioteka.Values)
            {
                if (god.Equals(k.DatumIzdavanja.Year))
                {
                    retval += k.IdKnjige;
                    retval += "\t" + k.ImeKnjige;
                    retval += " " + k.ImeAutora;
                    retval += " " + k.PrezimeAutora;
                    retval += " " + k.Zanr;
                    retval += " " + k.DatumIzdavanja;
                }                
            }

            return retval;
        }

        public string SpisakKnjigaZanr(string znr)
        {
            string retval = "Godina: " + znr + "\n";

            foreach (Knjiga k in BazaPodataka.Biblioteka.Values)
            {
                if (znr.Equals(k.Zanr.ToString()))
                {
                    retval += k.IdKnjige;
                    retval += "\t" + k.ImeKnjige;
                    retval += " " + k.ImeAutora;
                    retval += " " + k.PrezimeAutora;
                    retval += " " + k.Zanr;
                    retval += " " + k.DatumIzdavanja;
                }
            }

            return retval;
        }

        public string SpisakSvihKnjiga()
        {
            string retval = "Spisak svih knjiga:\n";

            foreach (Knjiga k in BazaPodataka.Biblioteka.Values)
            {
                retval += k.IdKnjige;
                retval += "\t" + k.ImeKnjige;
                retval += " " + k.ImeAutora;
                retval += " " + k.PrezimeAutora;
                retval += " " + k.Zanr;
                retval += " " + k.DatumIzdavanja;
            }

            return retval;
        }
    }
}
