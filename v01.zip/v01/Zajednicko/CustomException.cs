﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Zajednicko
{
    public class CustomException
    {
        // Polje
        private string message;

        // Properti
        public string Message { get => message; set => message = value; }
    }
}
