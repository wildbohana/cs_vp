﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Zajednicko
{
    public class Enumeracija
    {
        public enum Zanrovi 
        { 
            [EnumMember] krimi,
            [EnumMember] ljubav,
            [EnumMember] drama,
            [EnumMember] scifi 
        }
    }
}
