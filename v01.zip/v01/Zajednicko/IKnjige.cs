﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Zajednicko
{
    [ServiceContract]
    public interface IKnjige
    {
        [OperationContract]
        void DodajKnjigu(int idKnjige, string imeKnjige, string imeAutora, string prezimeAutora, Enumeracija.Zanrovi zanr, DateTime datumIzdavanja);

        [OperationContract]
        void ObrisiKnjigu(int idKnjige);

        [OperationContract]
        string SpisakSvihKnjiga();

        [OperationContract]
        string SpisakKnjigaAutor(string prz);

        [OperationContract]
        string SpisakKnjigaZanr(string znr);

        [OperationContract]
        string SpisakKnjigaGodina(int god);
    }
}
