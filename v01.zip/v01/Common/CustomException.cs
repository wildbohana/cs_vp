﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Common
{
    public class CustomException
    {
        // Polje
        private string message;

        // Properti
        public string Message { get => message; set => message = value; }
    }
}
