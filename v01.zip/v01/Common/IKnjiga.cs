﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    [ServiceContract]
    public interface IKnjiga
    {
        [OperationContract]
        void DodajKnjigu(int id);
        
        [OperationContract]
        void ObrisiKnjigu(int id);
        
        [OperationContract]
        string SpisakSvihKnjiga();

        [OperationContract]
        string SpisakKnjigaAutor();

        [OperationContract]
        string SpisakKnjigaZanr();

        [OperationContract]
        string SpisakKnjigaGodina();
    }
}
